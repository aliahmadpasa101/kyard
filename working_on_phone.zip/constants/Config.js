// const API_URL = 'http://customercaresupport-co.in/kyard/';
const API_URL = 'http://rkass.com/rkapp/';
const REQ_KEY = '4XupxUUPPOtGbeQ2S36DCWOBttZdwQ6q';

export default {
  API_URL,
  REQ_KEY,
};
